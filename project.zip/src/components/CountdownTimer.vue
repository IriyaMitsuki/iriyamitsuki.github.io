<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { countdownConfig } from '../config/countdown'
import { calculateTimeLeft } from '../utils/timeUtils'

const timeLeft = ref({
  days: 0,
  hours: 0,
  minutes: 0,
  seconds: 0
})

let timer

onMounted(() => {
  if (countdownConfig.enabled) {
    updateTimer()
    timer = setInterval(updateTimer, 1000)
  }
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
})

function updateTimer() {
  timeLeft.value = calculateTimeLeft(countdownConfig.targetDate)
}
</script>

<template>
  <div v-if="countdownConfig.enabled" class="countdown">
    <div class="countdown-item">
      <span class="number">{{ timeLeft.days }}</span>
      <span class="label">дней</span>
    </div>
    <div class="countdown-item">
      <span class="number">{{ timeLeft.hours }}</span>
      <span class="label">часов</span>
    </div>
    <div class="countdown-item">
      <span class="number">{{ timeLeft.minutes }}</span>
      <span class="label">минут</span>
    </div>
    <div class="countdown-item">
      <span class="number">{{ timeLeft.seconds }}</span>
      <span class="label">секунд</span>
    </div>
  </div>
</template>

<style scoped>
.countdown {
  display: flex;
  gap: 1rem;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(5px);
  padding: 1rem 2rem;
  border-radius: 1rem;
  margin-bottom: 2rem;
}

.countdown-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 80px;
}

.number {
  font-size: 2rem;
  font-weight: bold;
  color: white;
}

.label {
  font-size: 0.875rem;
  color: rgba(255, 255, 255, 0.8);
}

@media (max-width: 768px) {
  .countdown {
    gap: 0.5rem;
    padding: 0.75rem 1rem;
  }

  .countdown-item {
    min-width: 60px;
  }

  .number {
    font-size: 1.5rem;
  }

  .label {
    font-size: 0.75rem;
  }
}
</style>