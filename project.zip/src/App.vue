<script setup>
import CountdownTimer from './components/CountdownTimer.vue'
</script>

<template>
  <div class="background">
    <div class="overlay">
      <div class="content">
        <CountdownTimer />
        <div class="social-icons">
          <a href="https://youtube.com" target="_blank" class="icon youtube">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24"><path fill="currentColor" d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0C.488 3.45.029 5.804 0 12c.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0C23.512 20.55 23.971 18.196 24 12c-.029-6.185-.484-8.549-4.385-8.816zM9 16V8l8 3.993L9 16z"/></svg>
          </a>
          <a href="https://vk.com" target="_blank" class="icon vk">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24"><path fill="currentColor" d="M15.07 2H8.93C3.33 2 2 3.33 2 8.93v6.14C2 20.67 3.33 22 8.93 22h6.14c5.6 0 6.93-1.33 6.93-6.93V8.93C22 3.33 20.67 2 15.07 2zm3.08 14.27h-1.46c-.55 0-.72-.44-1.71-1.42c-.87-.83-1.25-.94-1.46-.94c-.3 0-.39.08-.39.47v1.3c0 .33-.11.53-.99.53c-1.46 0-3.09-.88-4.23-2.52c-1.72-2.42-2.19-4.23-2.19-4.6c0-.2.07-.39.47-.39h1.46c.35 0 .51.17.66.58c.72 2.06 1.92 3.88 2.41 3.88c.19 0 .28-.09.28-.57V10.7c-.06-1.02-.61-1.1-.61-1.46c0-.17.14-.35.37-.35h2.29c.31 0 .42.17.42.54v2.89c0 .31.13.42.23.42c.19 0 .34-.11.69-.46c1.07-1.19 1.84-3.03 1.84-3.03c.1-.22.27-.42.66-.42h1.46c.44 0 .54.23.44.54c-.18.85-1.96 3.36-1.96 3.36c-.16.26-.22.37 0 .66c.16.22.69.66 1.04 1.06c.65.71 1.15 1.31 1.29 1.73c.15.4-.09.61-.51.61z"/></svg>
          </a>
          <a href="https://telegram.org" target="_blank" class="icon telegram">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24"><path fill="currentColor" d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12a12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472c-.18 1.898-.962 6.502-1.36 8.627c-.168.9-.499 1.201-.82 1.23c-.696.065-1.225-.46-1.9-.902c-1.056-.693-1.653-1.124-2.678-1.8c-1.185-.78-.417-1.21.258-1.91c.177-.184 3.247-2.977 3.307-3.23c.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345c-.48.33-.913.49-1.302.48c-.428-.008-1.252-.241-1.865-.44c-.752-.245-1.349-.374-1.297-.789c.027-.216.325-.437.893-.663c3.498-1.524 5.83-2.529 6.998-3.014c3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
.background {
  position: relative;
  width: 100vw;
  height: 100vh;
  background-image: url('https://images.unsplash.com/photo-1707343843437-caacff5cfa74');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

.overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  display: flex;
  justify-content: center;
  align-items: center;
}

.content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2rem;
}

.social-icons {
  display: flex;
  gap: 2rem;
}

.icon {
  color: white;
  transition: all 0.3s ease;
  padding: 1rem;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(5px);
}

.icon:hover {
  transform: translateY(-5px);
  background: rgba(255, 255, 255, 0.2);
}

.youtube:hover {
  color: #FF0000;
}

.vk:hover {
  color: #4C75A3;
}

.telegram:hover {
  color: #0088cc;
}

@media (max-width: 768px) {
  .social-icons {
    gap: 1rem;
  }
  
  .icon svg {
    width: 24px;
    height: 24px;
  }
}
</style>