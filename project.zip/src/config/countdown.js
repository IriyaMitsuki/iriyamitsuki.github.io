export const countdownConfig = {
  targetDate: '2025-12-31T23:59:59', // Формат: YYYY-MM-DDTHH:mm:ss
  enabled: true
}